'use strict';

let capture = (() => {
    var _ref = _asyncToGenerator(function* () {
        const browser = yield puppeteer.launch({
            headless: true,
            executablePath: execPath,
            args: ['--disable-gpu']
        });
        const page = yield browser.newPage();
        yield page.goto(url);
        yield page.screenshot({ path: imagePath });
        yield browser.close();
    });

    return function capture() {
        return _ref.apply(this, arguments);
    };
})();

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { step("next", value); }, function (err) { step("throw", err); }); } } return step("next"); }); }; }

const fs = require('fs');
const path = require('path');
const tar = require('tar');
const puppeteer = require('puppeteer');
const aws = require('aws-sdk');
const s3 = new aws.S3({ apiVersion: '2006-03-01' });

const tmpPath = '/tmp';
const execPath = tmpPath + '/headless_shell';
const imageName = 'screenshot.png';
const imagePath = tmpPath + '/' + imageName;
const tarPath = path.join('HeadlessChrome-63.0.3213.0.tar.gz');
const url = 'https://www.google.co.jp/';
const bucket = 'chrome-health-check';
const key = imageName;

exports.handler = (event, context, callback) => {
    setupChrome().then(() => capture()).then(() => upload()).then(() => callback(null, 'Success')).catch(err => callback(err, null));
};

function setupChrome() {
    return new Promise((resolve, reject) => {
        if (isFileExisting(execPath)) {
            resolve();
            return;
        }

        fs.createReadStream(tarPath).on('error', err => reject(err)).pipe(tar.x({ C: tmpPath })).on('error', err => reject(err)).on('end', () => resolve());
    });
}

function isFileExisting(path) {
    try {
        fs.statSync(path);
        return true;
    } catch (err) {
        return false;
    }
}

function upload() {
    return new Promise((resolve, reject) => {
        s3.upload({
            Bucket: bucket,
            Key: key,
            Body: fs.createReadStream(imagePath)
        }, err => {
            if (err) reject(err);
            resolve();
        });
    });
}
